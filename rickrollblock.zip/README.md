# Rick Roll Blocker

A Firefox extension used to protect you from pesky Rick Roll attempts.

## Build instructions

Clone the git repository and then run

```
npm install 
npm run dist
```


## Development
You can also use the below script to continuously update the build folder upon changes to the source code

```
npm run watch
```

### Built with

node version: v12.18.3
npm version: 6.14.8