export interface ProtectionMessage {
    url: string;
}